/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.sise.capas.dao.mysql;

import com.edu.sise.capas.dao.Conexion;
import com.edu.sise.capas.dao.IDAOManager;
import java.sql.Connection;
import com.edu.sise.capas.dao.ILibroDAO;

/**
 *
 * @author Carlos
 */
public class MySqlDAOManager implements IDAOManager{
    //Singleton - parte 1
    private static final MySqlDAOManager instancia = new MySqlDAOManager();
    private Connection cn;
    
    private MySqlDAOManager(){
        cn = new Conexion().getConn();
    }
    
    //Singleton - parte 2
    public static MySqlDAOManager getInstancia(){
        return instancia;
    }
    
    //Factory
    private ILibroDAO libroDao = null;
    
    @Override
    public ILibroDAO getLibroDAO() {
        if(libroDao==null){
            libroDao = new MySqlLibroDAO1(cn);
        }
        return libroDao;
    }
    
}
