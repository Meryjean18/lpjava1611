/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.sise.capas.dao.mysql;

import com.edu.sise.capas.dao.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.edu.sise.capas.dao.ILibroDAO;
import com.edu.sise.capas.entity.Libro;

/**
 *
 * @author Carlos
 */
public class MySqlLibroDAO1 implements ILibroDAO{
    
    final String INSERT = "INSERT INTO libro(ISBN, titulo, descripcion, nro_edicion, anio_edicion, nro_paginas, stock, precio) "
            + " VALUES(?, ?, ?, ?, ?,?,?,?)";
    final String GETALL = "SELECT * FROM libro";
    final String UPDATE=  "UPDATE libro "
            + " SET ISBN = ?, titulo = ?, descripcion = ?, nro_edicion = ? , anio_edicion = ? , nro_paginas = ?, stock = ?, precio = ?"
            + " WHERE id_libro = ?";
    final String BUSQUEDA = "SELECT * FROM libro "
            + " WHERE titulo LIKE ? || descripcion LIKE ? ";
    final String DELETE = "DELETE FROM libro WHERE id_libro = ?";
    
    private Connection cn;

    public MySqlLibroDAO1(Connection cn) {
        this.cn = cn;
    }

    @Override
    public double calcularBonificiacion() throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Libro> obtenerTodos() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Libro> lista = new ArrayList<>();
        try {
            ps = cn.prepareStatement(GETALL);
            rs = ps.executeQuery();
            while(rs.next()){
                lista.add(getRS(rs));
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }finally{
            try{
                if(rs!=null) rs.close();
                if(ps!=null) ps.close();
            }catch(SQLException ex){
                throw new DAOException("Error en SQL", ex);
            }
        }
        return lista;
    }

    @Override
    public Libro obtenerxID(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Libro getRS(ResultSet rs) throws SQLException{
        return new Libro(
                rs.getInt("id_libro"),
                rs.getString("ISBN"),
                rs.getString("titulo"),
                rs.getString("descripcion"),
                rs.getInt("nro_edicion"),
                rs.getInt("anio_edicion"),
                rs.getInt("nro_paginas"),
                rs.getInt("stock"),
                rs.getDouble("precio")
            );
    }

    @Override
    public List<Libro> obtenerBusqueda(String v1) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Libro> lista = new ArrayList<>();
        String valor ="%"+v1+"%";        
        try {
            ps = cn.prepareStatement(BUSQUEDA);
            int i =1;
            ps.setString(i++, valor);
            ps.setString(i++, valor);
            rs = ps.executeQuery();
            while(rs.next()){
                lista.add(getRS(rs));
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }finally{
            try{
                if(rs!=null) rs.close();
                if(ps!=null) ps.close();
            }catch(SQLException ex){
                throw new DAOException("Error en SQL", ex);
            }
        }
        return lista;
    }   

    @Override
    public void nuevo(Libro o) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try{
            ps = cn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setString(i++,o.getISBN());
                ps.setString(i++,o.getTitulo());
                ps.setString(i++,o.getDescripcion());
                ps.setInt(i++,o.getNro_edicion());
                ps.setInt(i++,o.getAnio_edicion());
                ps.setInt(i++,o.getNro_paginas());
                ps.setInt(i++,o.getStock());
                ps.setDouble(i++, o.getPrecio());
            
            if(ps.executeUpdate()==0)
                throw new DAOException("No se pudo realizar el registro!!!");
            
            rs = ps.getGeneratedKeys();
            if(rs.next()){
                o.setId_libro(rs.getInt(1));
            }else{
                throw new DAOException("No se puede generar el ID del libro");
            }    
        } catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }finally{
            try{
                if(rs!=null) rs.close();
                if(ps!=null) ps.close();
            }catch(SQLException ex){
                throw new DAOException("Error en SQL", ex);
            }
        }
    }

    @Override
    public void editar(Libro o) throws DAOException {
        PreparedStatement ps = null;
        
        try{
            ps = cn.prepareStatement(UPDATE);
            int i = 1;
                ps.setString(i++,o.getISBN());
                ps.setString(i++,o.getTitulo());
                ps.setString(i++,o.getDescripcion());
                ps.setInt(i++,o.getNro_edicion());
                ps.setInt(i++,o.getAnio_edicion());
                ps.setInt(i++,o.getNro_paginas());
                ps.setInt(i++,o.getStock());
                ps.setDouble(i++,o.getPrecio());
                ps.setInt(i++, o.getId_libro());
            
            if(ps.executeUpdate()==0)
                throw new DAOException("No se pudo modificar el registro!!!");
        } catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }finally{
            try{
                if(ps!=null) ps.close();
            }catch(SQLException ex){
                throw new DAOException("Error en SQL", ex);
            }
        }
    }

    @Override
    public void eliminar(Libro o) throws DAOException {
        PreparedStatement ps = null;
        try{
            ps = cn.prepareStatement(DELETE);
            int i = 1;
            ps.setInt(i++, o.getId_libro());
            if(ps.executeUpdate()==0)
                throw new DAOException("No se pudo eliminar el registro!!!");
        } catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }finally{
            try{
                if(ps!=null) ps.close();
            }catch(SQLException ex){
                throw new DAOException("Error en SQL", ex);
            }
        }
    }

    
}
