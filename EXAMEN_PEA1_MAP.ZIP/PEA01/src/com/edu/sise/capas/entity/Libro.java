/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.sise.capas.entity;



/**
 *
 * @author Carlos
 */
public class Libro {
    private Integer id_libro;
    private String ISBN;
    private String titulo;
    private String descripcion;
    private Integer nro_edicion;
    private Integer anio_edicion;
    private Integer nro_paginas;
    private Integer stock; 
    private double precio;

    public Libro() {
    }

    public Libro(Integer id_libro, String ISBN, String titulo, String descripcion, Integer nro_edicion, Integer anio_edicion, Integer nro_paginas, Integer stock, double precio) {
        this.id_libro = id_libro;
        this.ISBN = ISBN;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.nro_edicion = nro_edicion;
        this.anio_edicion = anio_edicion;
        this.nro_paginas = nro_paginas;
        this.stock = stock;
        this.precio = precio;
    }

    public Integer getId_libro() {
        return id_libro;
    }

    public void setId_libro(Integer id_libro) {
        this.id_libro = id_libro;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getNro_edicion() {
        return nro_edicion;
    }

    public void setNro_edicion(Integer nro_edicion) {
        this.nro_edicion = nro_edicion;
    }

    public Integer getAnio_edicion() {
        return anio_edicion;
    }

    public void setAnio_edicion(Integer anio_edicion) {
        this.anio_edicion = anio_edicion;
    }

    public Integer getNro_paginas() {
        return nro_paginas;
    }

    public void setNro_paginas(Integer nro_paginas) {
        this.nro_paginas = nro_paginas;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    
}
