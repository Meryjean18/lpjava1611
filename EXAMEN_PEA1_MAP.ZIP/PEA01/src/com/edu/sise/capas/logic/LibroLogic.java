/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.sise.capas.logic;

import com.edu.sise.capas.dao.mysql.MySqlDAOManager;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.edu.sise.capas.dao.ILibroDAO;
import com.edu.sise.capas.entity.Libro;

/**
 *
 * @author Carlos
 */
public class LibroLogic {
    
    MySqlDAOManager factory = MySqlDAOManager.getInstancia(); //Singleton
    ILibroDAO dao = factory.getLibroDAO();
    
    private DefaultTableModel obtenerTodos() throws Exception{
        DefaultTableModel modelo = getModelo();
        List<Libro> lista = dao.obtenerTodos();
        for(Libro obj : lista){
            Object data[] = {
              obj.getId_libro(),
              obj.getISBN(),
              obj.getTitulo(),
              obj.getDescripcion(),
              obj.getNro_edicion(),
              obj.getAnio_edicion(),
              obj.getNro_paginas(),
              obj.getStock(),
              obj.getPrecio()
            };
            modelo.addRow(data);
        }
        return modelo;
    }
    
    public DefaultTableModel obtenerBusqueda(String v1) throws Exception{
        DefaultTableModel modelo = getModelo();
        List<Libro> lista = dao.obtenerBusqueda(v1);
        for(Libro obj : lista){
            Object data[] = {
              obj.getId_libro(),
              obj.getISBN(),
              obj.getTitulo(),
              obj.getDescripcion(),
              obj.getNro_edicion(),
              obj.getAnio_edicion(),
              obj.getNro_paginas(),
              obj.getStock(),
              obj.getPrecio()
            };
            modelo.addRow(data);
        }
        return modelo;
    }
    
    public void imprimirTB(JTable jtable) throws Exception{
        jtable.setModel(obtenerTodos());
    }
    
    public void imprimirTB(JTable jtable, DefaultTableModel modelo) throws Exception{
        jtable.setModel(modelo);
    }
    
    public void nuevo(Libro o) throws Exception{
        dao.nuevo(o);
    }
    
    public void editar(Libro o) throws Exception{
        dao.editar(o);
    }
    
    public void eliminar(Libro o) throws Exception{
        dao.eliminar(o);
    }
    
    private DefaultTableModel getModelo(){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("ISBN");
        modelo.addColumn("TITULO");
        modelo.addColumn("DESCRIPCION");
        modelo.addColumn("NRO. EDICION");
        modelo.addColumn("AÑO. EDICION");
        modelo.addColumn("NRO. PAGINAS");
        modelo.addColumn("STOCK");
        modelo.addColumn("PRECIO");
        return modelo;
    }
    

}
